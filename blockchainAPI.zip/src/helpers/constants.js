/**
 * Constants used through the app.
 * */

module.exports = {
    VALIDATION_WINDOW: 300,
    DEFAULT_REG_REQUEST_MESSAGE: "starRegistry",
    STORY_MAX_LENGTH: 250
};